import 'package:flutter/material.dart';
import 'package:umango_s_application5/core/app_export.dart';

class AppStyle {
  static TextStyle txtRalewayRomanBold28 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      28,
    ),
    fontFamily: 'Raleway',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoRomanSemiBold18 = TextStyle(
    color: ColorConstant.gray901,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtRobotoRomanMedium9 = TextStyle(
    color: ColorConstant.gray400Bf,
    fontSize: getFontSize(
      9,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtRalewayRomanRegular12Bluegray202 = TextStyle(
    color: ColorConstant.bluegray202,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Raleway',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRomanBold24 = TextStyle(
    color: ColorConstant.orangeA700,
    fontSize: getFontSize(
      24,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtMontserratRomanMedium20Gray900 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtRalewayRomanRegular12 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Raleway',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRomanMedium14 = TextStyle(
    color: ColorConstant.bluegray202,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtMontserratRomanSemiBold32 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      32,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtPoppinsMedium10 = TextStyle(
    color: ColorConstant.gray500Bf,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtLatoRegular12 = TextStyle(
    color: ColorConstant.black901,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Lato',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRalewayRomanBold20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Raleway',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black904,
    fontSize: getFontSize(
      20,
    ),
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanBold24 = TextStyle(
    color: ColorConstant.gray901,
    fontSize: getFontSize(
      24,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtLatoBold20 = TextStyle(
    color: ColorConstant.bluegray203,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Lato',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoRegular20Black90412 = TextStyle(
    color: ColorConstant.black904,
    fontSize: getFontSize(
      20,
    ),
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRalewayRomanSemiBold20 = TextStyle(
    color: ColorConstant.black902,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Raleway',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtLatoRegular16 = TextStyle(
    color: ColorConstant.bluegray103,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Lato',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular20Black904 = TextStyle(
    color: ColorConstant.black904,
    fontSize: getFontSize(
      20,
    ),
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRomanLight14 = TextStyle(
    color: ColorConstant.bluegray200,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w300,
  );

  static TextStyle txtRobotoRomanRegular15 = TextStyle(
    color: ColorConstant.gray901,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRomanRegular16 = TextStyle(
    color: ColorConstant.black902,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.bluegray400,
    fontSize: getFontSize(
      16,
    ),
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtLatoRegular12Bluegray103 = TextStyle(
    color: ColorConstant.bluegray103,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Lato',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtPoppinsMedium10WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtMontserratRomanMedium20 = TextStyle(
    color: ColorConstant.bluegray202,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtRobotoRomanRegular12 = TextStyle(
    color: ColorConstant.black901,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanSemiBold10 = TextStyle(
    color: ColorConstant.black901,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtRobotoRomanMedium16 = TextStyle(
    color: ColorConstant.gray700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtMontserratRomanLight12 = TextStyle(
    color: ColorConstant.bluegray202,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w300,
  );
}
