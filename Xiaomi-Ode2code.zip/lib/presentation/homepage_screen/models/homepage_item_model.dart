class HomepageItemModel {}
