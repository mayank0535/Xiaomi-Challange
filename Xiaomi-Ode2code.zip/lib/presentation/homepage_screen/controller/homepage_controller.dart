import '/core/app_export.dart';
import 'package:umango_s_application5/presentation/homepage_screen/models/homepage_model.dart';
import 'package:flutter/material.dart';

class HomepageController extends GetxController {
  TextEditingController frameSixController = TextEditingController();

  TextEditingController octController = TextEditingController();

  Rx<HomepageModel> homepageModelObj = HomepageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    frameSixController.dispose();
    octController.dispose();
  }
}
