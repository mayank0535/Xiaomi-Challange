import '../controller/homepage_controller.dart';
import '../models/homepage_item_model.dart';
import 'package:flutter/material.dart';
import 'package:umango_s_application5/core/app_export.dart';

// ignore: must_be_immutable
class HomepageItemWidget extends StatelessWidget {
  HomepageItemWidget(this.homepageItemModelObj, {this.onTapAutoLayoutVer});

  HomepageItemModel homepageItemModelObj;

  var controller = Get.find<HomepageController>();

  VoidCallback? onTapAutoLayoutVer;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: GestureDetector(
        onTap: () {
          onTapAutoLayoutVer!();
        },
        child: Container(
          margin: getMargin(
            top: 10.0,
            bottom: 10.0,
          ),
          decoration: AppDecoration.outlineBlack9000c1.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder24,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            children: [
              Padding(
                padding: getPadding(
                  left: 28,
                  top: 17,
                  bottom: 17,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(
                    getHorizontalSize(
                      40.00,
                    ),
                  ),
                  child: CommonImageView(
                    imagePath: ImageConstant.imgEllipse,
                    height: getSize(
                      80.00,
                    ),
                    width: getSize(
                      80.00,
                    ),
                  ),
                ),
              ),
              Container(
                margin: getMargin(
                  left: 30,
                  top: 16,
                  right: 42,
                  bottom: 16,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      margin: getMargin(
                        right: 10,
                      ),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "lbl_name".tr,
                              style: TextStyle(
                                color: ColorConstant.gray901,
                                fontSize: getFontSize(
                                  15,
                                ),
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                                letterSpacing: 0.20,
                              ),
                            ),
                            TextSpan(
                              text: "lbl_abdul_karim".tr,
                              style: TextStyle(
                                color: ColorConstant.gray601,
                                fontSize: getFontSize(
                                  15,
                                ),
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                                letterSpacing: 0.20,
                              ),
                            ),
                          ],
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    Container(
                      margin: getMargin(
                        top: 18,
                      ),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "lbl_order_id".tr,
                              style: TextStyle(
                                color: ColorConstant.gray901,
                                fontSize: getFontSize(
                                  15,
                                ),
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                                letterSpacing: 0.20,
                              ),
                            ),
                            TextSpan(
                              text: "lbl_362736277289".tr,
                              style: TextStyle(
                                color: ColorConstant.gray601,
                                fontSize: getFontSize(
                                  15,
                                ),
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                                letterSpacing: 0.20,
                              ),
                            ),
                          ],
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    Container(
                      margin: getMargin(
                        top: 18,
                        right: 10,
                      ),
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "lbl_order_bill".tr,
                              style: TextStyle(
                                color: ColorConstant.gray901,
                                fontSize: getFontSize(
                                  15,
                                ),
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                                letterSpacing: 0.20,
                              ),
                            ),
                            TextSpan(
                              text: "lbl_125".tr,
                              style: TextStyle(
                                color: ColorConstant.gray601,
                                fontSize: getFontSize(
                                  15,
                                ),
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                                letterSpacing: 0.20,
                              ),
                            ),
                          ],
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
