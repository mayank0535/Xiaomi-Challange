import '../homepage_screen/widgets/homepage_item_widget.dart';
import 'controller/homepage_controller.dart';
import 'models/homepage_item_model.dart';
import 'package:flutter/material.dart';
import 'package:umango_s_application5/core/app_export.dart';
import 'package:umango_s_application5/widgets/custom_icon_button.dart';
import 'package:umango_s_application5/widgets/custom_text_form_field.dart';

class HomepageScreen extends GetWidget<HomepageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Column(children: [
              Expanded(
                  child: Container(
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                    Container(
                        width: size.width,
                        decoration: BoxDecoration(
                            color: ColorConstant.whiteA700,
                            boxShadow: [
                              BoxShadow(
                                  color: ColorConstant.black9000c,
                                  spreadRadius: getHorizontalSize(2.00),
                                  blurRadius: getHorizontalSize(2.00),
                                  offset: Offset(0, 4))
                            ]),
                        child: Padding(
                            padding: getPadding(
                                left: 23, top: 30, right: 23, bottom: 10),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  CustomTextFormField(
                                      width: 224,
                                      focusNode: FocusNode(),
                                      controller: controller.frameSixController,
                                      hintText: "lbl_search_products".tr,
                                      variant: TextFormFieldVariant
                                          .FillBluegray2007f,
                                      padding: TextFormFieldPadding.PaddingT12,
                                      fontStyle:
                                          TextFormFieldFontStyle.LatoRegular16),
                                  CustomIconButton(
                                      height: 40,
                                      width: 40,
                                      margin: getMargin(left: 12),
                                      variant:
                                          IconButtonVariant.OutlineBluegray202,
                                      shape: IconButtonShape.CircleBorder20,
                                      padding: IconButtonPadding.PaddingAll10,
                                      child: CommonImageView(
                                          imagePath: ImageConstant.imgGroup30)),
                                  Padding(
                                      padding: getPadding(left: 12),
                                      child: ClipRRect(
                                          borderRadius: BorderRadius.circular(
                                              getHorizontalSize(20.00)),
                                          child: CommonImageView(
                                              imagePath:
                                                  ImageConstant.imgEllipse1,
                                              height: getSize(40.00),
                                              width: getSize(40.00))))
                                ]))),
                    Expanded(
                        child: SingleChildScrollView(
                            padding: getPadding(top: 16),
                            child: Container(
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                  Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                          padding:
                                              getPadding(left: 27, right: 27),
                                          child: Text("msg_good_morning_j".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle.txtLatoBold20
                                                  .copyWith()))),
                                  Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                          padding: getPadding(
                                              left: 24, top: 16, right: 24),
                                          child: Text("msg_get_ready_for_w".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRalewayRomanBold28
                                                  .copyWith()))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          margin: getMargin(
                                              left: 4, top: 11, right: 4),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            right: 1),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              Container(
                                                                  margin:
                                                                      getMargin(
                                                                          bottom:
                                                                              23),
                                                                  child: Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .end,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Align(
                                                                            alignment: Alignment
                                                                                .centerLeft,
                                                                            child: Text("lbl_total_visits".tr,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                textAlign: TextAlign.left,
                                                                                style: AppStyle.txtRobotoRomanSemiBold10.copyWith())),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 10, top: 37),
                                                                            child: Text("lbl_1500_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtRobotoRomanMedium9.copyWith())),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 10, top: 37),
                                                                            child: Text("lbl_1000_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtRobotoRomanMedium9.copyWith())),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 10, top: 37),
                                                                            child: Text("lbl_500_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtRobotoRomanMedium9.copyWith())),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 10, top: 37),
                                                                            child: Text("lbl_100_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtRobotoRomanMedium9.copyWith())),
                                                                        Padding(
                                                                            padding: getPadding(
                                                                                left: 39,
                                                                                top: 37,
                                                                                right: 3),
                                                                            child: Text("lbl_0".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtRobotoRomanMedium9.copyWith()))
                                                                      ])),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              33),
                                                                  child: CommonImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgSchema,
                                                                      height: getVerticalSize(
                                                                          235.00),
                                                                      width: getHorizontalSize(
                                                                          311.00)))
                                                            ]))),
                                                Align(
                                                    alignment:
                                                        Alignment.centerRight,
                                                    child: Container(
                                                        margin: getMargin(
                                                            left: 46,
                                                            top: 7,
                                                            right: 6),
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        10.00))),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .end,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              CustomTextFormField(
                                                                  width: 38,
                                                                  focusNode:
                                                                      FocusNode(),
                                                                  controller: controller
                                                                      .octController,
                                                                  hintText:
                                                                      "lbl_oct"
                                                                          .tr,
                                                                  margin:
                                                                      getMargin(
                                                                          top:
                                                                              1),
                                                                  variant:
                                                                      TextFormFieldVariant
                                                                          .FillWhiteA700,
                                                                  shape: TextFormFieldShape
                                                                      .RoundedBorder10,
                                                                  padding:
                                                                      TextFormFieldPadding
                                                                          .PaddingAll8,
                                                                  fontStyle:
                                                                      TextFormFieldFontStyle
                                                                          .PoppinsMedium10,
                                                                  textInputAction:
                                                                      TextInputAction
                                                                          .done),
                                                              Container(
                                                                  margin:
                                                                      getMargin(
                                                                          left:
                                                                              48,
                                                                          top:
                                                                              1),
                                                                  padding: getPadding(
                                                                      left: 9,
                                                                      top: 8,
                                                                      bottom:
                                                                          8),
                                                                  decoration: AppDecoration
                                                                      .txtFillWhiteA700
                                                                      .copyWith(
                                                                          borderRadius:
                                                                              BorderRadiusStyle
                                                                                  .txtRoundedBorder10),
                                                                  child: Text(
                                                                      "lbl_nov"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtPoppinsMedium10
                                                                          .copyWith())),
                                                              Container(
                                                                  margin:
                                                                      getMargin(
                                                                          left:
                                                                              55,
                                                                          top:
                                                                              1),
                                                                  padding: getPadding(
                                                                      left: 9,
                                                                      top: 8,
                                                                      bottom:
                                                                          8),
                                                                  decoration: AppDecoration
                                                                      .txtGradientOrangeA700OrangeA700
                                                                      .copyWith(
                                                                          borderRadius:
                                                                              BorderRadiusStyle
                                                                                  .txtRoundedBorder10),
                                                                  child: Text(
                                                                      "lbl_dec"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtPoppinsMedium10WhiteA700
                                                                          .copyWith())),
                                                              Container(
                                                                  margin: getMargin(
                                                                      left: 55,
                                                                      bottom:
                                                                          1),
                                                                  padding: getPadding(
                                                                      left: 5,
                                                                      top: 10,
                                                                      bottom:
                                                                          6),
                                                                  decoration: AppDecoration
                                                                      .txtFillWhiteA700
                                                                      .copyWith(
                                                                          borderRadius: BorderRadiusStyle
                                                                              .txtRoundedBorder10),
                                                                  child: Text(
                                                                      "lbl_janv"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtPoppinsMedium10
                                                                          .copyWith()))
                                                            ])))
                                              ]))),
                                  Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                          padding: getPadding(
                                              left: 18, top: 31, right: 18),
                                          child: Text("msg_products_catego".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRalewayRomanBold20
                                                  .copyWith()))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Padding(
                                          padding: getPadding(
                                              left: 10, top: 19, right: 9),
                                          child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    30.00))),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              30.00)),
                                                                  child: CommonImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgUnsplashagzyfs,
                                                                      height: getSize(
                                                                          60.00),
                                                                      width: getSize(
                                                                          60.00)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      left: 10,
                                                                      top: 12,
                                                                      right: 9),
                                                              child: Text(
                                                                  "lbl_phones"
                                                                      .tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtRobotoRomanRegular12
                                                                      .copyWith()))
                                                        ])),
                                                Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    30.00))),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              30.00)),
                                                                  child: CommonImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgUnsplashlxvxpa,
                                                                      height: getSize(
                                                                          60.00),
                                                                      width: getSize(
                                                                          60.00)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      left: 14,
                                                                      top: 12,
                                                                      right:
                                                                          13),
                                                              child: Text(
                                                                  "lbl_home".tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtRobotoRomanRegular12
                                                                      .copyWith()))
                                                        ])),
                                                Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    30.00))),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              30.00)),
                                                                  child: CommonImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgUnsplashgrzokn,
                                                                      height: getSize(
                                                                          60.00),
                                                                      width: getSize(
                                                                          60.00)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      left: 23,
                                                                      top: 12,
                                                                      right:
                                                                          22),
                                                              child: Text(
                                                                  "lbl_tv".tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtRobotoRomanRegular12
                                                                      .copyWith()))
                                                        ])),
                                                Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    30.00))),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              30.00)),
                                                                  child: CommonImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgUnsplashf4qyr3,
                                                                      height: getSize(
                                                                          60.00),
                                                                      width: getSize(
                                                                          60.00)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      left: 15,
                                                                      top: 12,
                                                                      right:
                                                                          14),
                                                              child: Text(
                                                                  "lbl_audio"
                                                                      .tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtRobotoRomanRegular12
                                                                      .copyWith()))
                                                        ])),
                                                Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    30.00))),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              30.00)),
                                                                  child: CommonImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgUnsplashylverp,
                                                                      height: getSize(
                                                                          60.00),
                                                                      width: getSize(
                                                                          60.00)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      left: 8,
                                                                      top: 12,
                                                                      right: 8),
                                                              child: Text(
                                                                  "lbl_laptops"
                                                                      .tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtRobotoRomanRegular12
                                                                      .copyWith()))
                                                        ]))
                                              ]))),
                                  Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                          padding: getPadding(
                                              left: 18, top: 35, right: 18),
                                          child: Text("msg_trending_produc".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRalewayRomanBold20
                                                  .copyWith()))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          height: getVerticalSize(220.00),
                                          width: getHorizontalSize(343.00),
                                          margin: getMargin(
                                              left: 10, top: 23, right: 10),
                                          child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: ClipRRect(
                                                        borderRadius: BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00)),
                                                            topRight:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00))),
                                                        child: CommonImageView(
                                                            imagePath: ImageConstant
                                                                .imgUnsplashsg8nx,
                                                            height:
                                                                getVerticalSize(
                                                                    220.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    343.00)))),
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 15,
                                                            top: 40,
                                                            right: 15,
                                                            bottom: 40),
                                                        child: Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowleftBluegray101)),
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  margin:
                                                                      getMargin(
                                                                          left:
                                                                              263),
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright))
                                                            ])))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          width: double.infinity,
                                          margin:
                                              getMargin(left: 10, right: 10),
                                          decoration: AppDecoration
                                              .outlineBluegray103
                                              .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .customBorderBL20),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 22,
                                                            top: 16,
                                                            right: 15),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          bottom:
                                                                              2),
                                                                  child: Text(
                                                                      "lbl_mi_pro_laptop"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtRalewayRomanSemiBold20
                                                                          .copyWith())),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              8),
                                                                  child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      children: [
                                                                        Text(
                                                                            "lbl_600_00"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.txtLatoRegular12.copyWith()),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 6),
                                                                            child: Text("lbl_999_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtLatoRegular12Bluegray103.copyWith(decoration: TextDecoration.lineThrough)))
                                                                      ]))
                                                            ]))),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 3,
                                                        right: 22),
                                                    child: Text(
                                                        "msg_8gb_ram_250gb_s"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith())),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 7,
                                                        right: 22,
                                                        bottom: 6),
                                                    child: Text(
                                                        "msg_55_units_availa"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith()))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          height: getVerticalSize(220.00),
                                          width: getHorizontalSize(343.00),
                                          margin: getMargin(
                                              left: 10, top: 16, right: 10),
                                          child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: ClipRRect(
                                                        borderRadius: BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00)),
                                                            topRight:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00))),
                                                        child: CommonImageView(
                                                            imagePath: ImageConstant
                                                                .imgUnsplashsg8nx,
                                                            height:
                                                                getVerticalSize(
                                                                    220.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    343.00)))),
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 15,
                                                            top: 40,
                                                            right: 15,
                                                            bottom: 40),
                                                        child: Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowleftBluegray101)),
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  margin:
                                                                      getMargin(
                                                                          left:
                                                                              263),
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright))
                                                            ])))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          width: double.infinity,
                                          margin:
                                              getMargin(left: 10, right: 10),
                                          decoration: AppDecoration
                                              .outlineBluegray103
                                              .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .customBorderBL20),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 22,
                                                            top: 16,
                                                            right: 15),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          bottom:
                                                                              2),
                                                                  child: Text(
                                                                      "lbl_mi_pro_laptop"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtRalewayRomanSemiBold20
                                                                          .copyWith())),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              8),
                                                                  child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      children: [
                                                                        Text(
                                                                            "lbl_600_00"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.txtLatoRegular12.copyWith()),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 6),
                                                                            child: Text("lbl_999_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtLatoRegular12Bluegray103.copyWith(decoration: TextDecoration.lineThrough)))
                                                                      ]))
                                                            ]))),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 3,
                                                        right: 22),
                                                    child: Text(
                                                        "msg_8gb_ram_250gb_s"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith())),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 7,
                                                        right: 22,
                                                        bottom: 6),
                                                    child: Text(
                                                        "msg_55_units_availa"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith()))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          height: getVerticalSize(220.00),
                                          width: getHorizontalSize(343.00),
                                          margin: getMargin(
                                              left: 10, top: 15, right: 10),
                                          child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: ClipRRect(
                                                        borderRadius: BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00)),
                                                            topRight:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00))),
                                                        child: CommonImageView(
                                                            imagePath: ImageConstant
                                                                .imgUnsplashsg8nx,
                                                            height:
                                                                getVerticalSize(
                                                                    220.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    343.00)))),
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 15,
                                                            top: 40,
                                                            right: 15,
                                                            bottom: 40),
                                                        child: Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowleftBluegray101)),
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  margin:
                                                                      getMargin(
                                                                          left:
                                                                              263),
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright))
                                                            ])))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          width: double.infinity,
                                          margin:
                                              getMargin(left: 10, right: 10),
                                          decoration: AppDecoration
                                              .outlineBluegray103
                                              .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .customBorderBL20),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 22,
                                                            top: 16,
                                                            right: 15),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          bottom:
                                                                              2),
                                                                  child: Text(
                                                                      "lbl_mi_pro_laptop"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtRalewayRomanSemiBold20
                                                                          .copyWith())),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              8),
                                                                  child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      children: [
                                                                        Text(
                                                                            "lbl_600_00"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.txtLatoRegular12.copyWith()),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 6),
                                                                            child: Text("lbl_999_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtLatoRegular12Bluegray103.copyWith(decoration: TextDecoration.lineThrough)))
                                                                      ]))
                                                            ]))),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 3,
                                                        right: 22),
                                                    child: Text(
                                                        "msg_8gb_ram_250gb_s"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith())),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 7,
                                                        right: 22,
                                                        bottom: 6),
                                                    child: Text(
                                                        "msg_55_units_availa"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith()))
                                              ]))),
                                  Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                          padding: getPadding(
                                              left: 19, top: 33, right: 19),
                                          child: Text("lbl_new_products".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRalewayRomanBold20
                                                  .copyWith()))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          height: getVerticalSize(220.00),
                                          width: getHorizontalSize(343.00),
                                          margin: getMargin(
                                              left: 10, top: 25, right: 10),
                                          child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: ClipRRect(
                                                        borderRadius: BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00)),
                                                            topRight:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00))),
                                                        child: CommonImageView(
                                                            imagePath: ImageConstant
                                                                .imgUnsplashsg8nx,
                                                            height:
                                                                getVerticalSize(
                                                                    220.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    343.00)))),
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 15,
                                                            top: 40,
                                                            right: 15,
                                                            bottom: 40),
                                                        child: Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowleftBluegray101)),
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  margin:
                                                                      getMargin(
                                                                          left:
                                                                              263),
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright))
                                                            ])))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          width: double.infinity,
                                          margin:
                                              getMargin(left: 10, right: 10),
                                          decoration: AppDecoration
                                              .outlineBluegray103
                                              .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .customBorderBL20),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 22,
                                                            top: 16,
                                                            right: 15),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          bottom:
                                                                              2),
                                                                  child: Text(
                                                                      "lbl_mi_pro_laptop"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtRalewayRomanSemiBold20
                                                                          .copyWith())),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              8),
                                                                  child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      children: [
                                                                        Text(
                                                                            "lbl_600_00"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.txtLatoRegular12.copyWith()),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 6),
                                                                            child: Text("lbl_999_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtLatoRegular12Bluegray103.copyWith(decoration: TextDecoration.lineThrough)))
                                                                      ]))
                                                            ]))),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 3,
                                                        right: 22),
                                                    child: Text(
                                                        "msg_8gb_ram_250gb_s"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith())),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 7,
                                                        right: 22,
                                                        bottom: 6),
                                                    child: Text(
                                                        "msg_55_units_availa"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith()))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          height: getVerticalSize(220.00),
                                          width: getHorizontalSize(343.00),
                                          margin: getMargin(
                                              left: 10, top: 16, right: 10),
                                          child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: ClipRRect(
                                                        borderRadius: BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00)),
                                                            topRight:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00))),
                                                        child: CommonImageView(
                                                            imagePath: ImageConstant
                                                                .imgUnsplashsg8nx,
                                                            height:
                                                                getVerticalSize(
                                                                    220.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    343.00)))),
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 15,
                                                            top: 40,
                                                            right: 15,
                                                            bottom: 40),
                                                        child: Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowleftBluegray101)),
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  margin:
                                                                      getMargin(
                                                                          left:
                                                                              263),
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright))
                                                            ])))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          width: double.infinity,
                                          margin:
                                              getMargin(left: 10, right: 10),
                                          decoration: AppDecoration
                                              .outlineBluegray103
                                              .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .customBorderBL20),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 22,
                                                            top: 16,
                                                            right: 15),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          bottom:
                                                                              2),
                                                                  child: Text(
                                                                      "lbl_mi_pro_laptop"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtRalewayRomanSemiBold20
                                                                          .copyWith())),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              8),
                                                                  child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      children: [
                                                                        Text(
                                                                            "lbl_600_00"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.txtLatoRegular12.copyWith()),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 6),
                                                                            child: Text("lbl_999_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtLatoRegular12Bluegray103.copyWith(decoration: TextDecoration.lineThrough)))
                                                                      ]))
                                                            ]))),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 3,
                                                        right: 22),
                                                    child: Text(
                                                        "msg_8gb_ram_250gb_s"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith())),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 7,
                                                        right: 22,
                                                        bottom: 6),
                                                    child: Text(
                                                        "msg_55_units_availa"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith()))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          height: getVerticalSize(220.00),
                                          width: getHorizontalSize(343.00),
                                          margin: getMargin(
                                              left: 10, top: 15, right: 10),
                                          child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: ClipRRect(
                                                        borderRadius: BorderRadius.only(
                                                            topLeft:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00)),
                                                            topRight:
                                                                Radius.circular(
                                                                    getHorizontalSize(
                                                                        20.00))),
                                                        child: CommonImageView(
                                                            imagePath: ImageConstant
                                                                .imgUnsplashsg8nx,
                                                            height:
                                                                getVerticalSize(
                                                                    220.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    343.00)))),
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 15,
                                                            top: 40,
                                                            right: 15,
                                                            bottom: 40),
                                                        child: Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowleftBluegray101)),
                                                              CustomIconButton(
                                                                  height: 25,
                                                                  width: 25,
                                                                  margin:
                                                                      getMargin(
                                                                          left:
                                                                              263),
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright))
                                                            ])))
                                              ]))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          width: double.infinity,
                                          margin:
                                              getMargin(left: 10, right: 10),
                                          decoration: AppDecoration
                                              .outlineBluegray103
                                              .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .customBorderBL20),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            left: 22,
                                                            top: 16,
                                                            right: 15),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          bottom:
                                                                              2),
                                                                  child: Text(
                                                                      "lbl_mi_pro_laptop"
                                                                          .tr,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtRalewayRomanSemiBold20
                                                                          .copyWith())),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              8),
                                                                  child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      children: [
                                                                        Text(
                                                                            "lbl_600_00"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.txtLatoRegular12.copyWith()),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 6),
                                                                            child: Text("lbl_999_00".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtLatoRegular12Bluegray103.copyWith(decoration: TextDecoration.lineThrough)))
                                                                      ]))
                                                            ]))),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 3,
                                                        right: 22),
                                                    child: Text(
                                                        "msg_8gb_ram_250gb_s"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith())),
                                                Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 7,
                                                        right: 22,
                                                        bottom: 6),
                                                    child: Text(
                                                        "msg_55_units_availa"
                                                            .tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtLatoRegular16
                                                            .copyWith()))
                                              ]))),
                                  Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                          padding: getPadding(
                                              left: 18, top: 33, right: 18),
                                          child: Text("lbl_recent_orders".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRalewayRomanBold20
                                                  .copyWith()))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Padding(
                                          padding: getPadding(
                                              left: 10, top: 17, right: 10),
                                          child: Obx(() => ListView.builder(
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              shrinkWrap: true,
                                              itemCount: controller
                                                  .homepageModelObj
                                                  .value
                                                  .homepageItemList
                                                  .length,
                                              itemBuilder: (context, index) {
                                                HomepageItemModel model =
                                                    controller
                                                            .homepageModelObj
                                                            .value
                                                            .homepageItemList[
                                                        index];
                                                return HomepageItemWidget(model,
                                                    onTapAutoLayoutVer:
                                                        onTapAutoLayoutVer);
                                              })))),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          width: getHorizontalSize(315.00),
                                          margin: getMargin(
                                              left: 10, top: 28, right: 10),
                                          child: RichText(
                                              text: TextSpan(children: [
                                                TextSpan(
                                                    text: "msg_mi_store_bandr2"
                                                        .tr,
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .black902,
                                                        fontSize:
                                                            getFontSize(16),
                                                        fontFamily:
                                                            'Montserrat',
                                                        fontWeight:
                                                            FontWeight.w400)),
                                                TextSpan(
                                                    text:
                                                        "msg_copyright_xiao".tr,
                                                    style: TextStyle(
                                                        color: ColorConstant
                                                            .black902,
                                                        fontSize:
                                                            getFontSize(16),
                                                        fontFamily:
                                                            'Montserrat',
                                                        fontWeight:
                                                            FontWeight.w400))
                                              ]),
                                              textAlign: TextAlign.center))),
                                  Align(
                                      alignment: Alignment.centerLeft,
                                      child: Container(
                                          height: getVerticalSize(45.00),
                                          width: size.width,
                                          margin: getMargin(top: 118),
                                          decoration: BoxDecoration(
                                              color:
                                                  ColorConstant.bluegray10063)))
                                ]))))
                  ]))),
              Container(
                  decoration: BoxDecoration(
                      color: ColorConstant.whiteA700,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(getHorizontalSize(20.00)),
                          topRight: Radius.circular(getHorizontalSize(20.00))),
                      boxShadow: [
                        BoxShadow(
                            color: ColorConstant.black90019,
                            spreadRadius: getHorizontalSize(2.00),
                            blurRadius: getHorizontalSize(2.00),
                            offset: Offset(0, -4))
                      ]),
                  child: Padding(
                      padding: getPadding(top: 8, bottom: 8),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Container(
                                margin: getMargin(top: 3),
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Padding(
                                          padding:
                                              getPadding(left: 6, right: 7),
                                          child: CommonImageView(
                                              svgPath:
                                                  ImageConstant.imgHome19X20,
                                              height: getVerticalSize(19.00),
                                              width: getHorizontalSize(20.00))),
                                      Align(
                                          alignment: Alignment.centerLeft,
                                          child: Padding(
                                              padding: getPadding(top: 7),
                                              child: Text("lbl_home".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRalewayRomanRegular12
                                                      .copyWith())))
                                    ])),
                            Container(
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                  Padding(
                                      padding:
                                          getPadding(left: 2, top: 3, right: 2),
                                      child: CommonImageView(
                                          svgPath: ImageConstant.imgCart18X20,
                                          height: getVerticalSize(18.00),
                                          width: getHorizontalSize(20.00))),
                                  Padding(
                                      padding:
                                          getPadding(left: 1, top: 8, right: 1),
                                      child: Text("lbl_cart".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtRalewayRomanRegular12Bluegray202
                                              .copyWith()))
                                ])),
                            Container(
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                  Align(
                                      alignment: Alignment.center,
                                      child: Padding(
                                          padding:
                                              getPadding(left: 3, right: 4),
                                          child: CommonImageView(
                                              svgPath: ImageConstant.imgQrcode,
                                              height: getSize(25.00),
                                              width: getSize(25.00)))),
                                  Padding(
                                      padding: getPadding(top: 5),
                                      child: Text("lbl_scan".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtRalewayRomanRegular12Bluegray202
                                              .copyWith()))
                                ])),
                            Container(
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                  Padding(
                                      padding: getPadding(left: 6, right: 4),
                                      child: CommonImageView(
                                          svgPath: ImageConstant.imgMinimize,
                                          height: getVerticalSize(25.00),
                                          width: getHorizontalSize(26.00))),
                                  Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                          padding: getPadding(top: 5),
                                          child: Text("lbl_orders".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRalewayRomanRegular12Bluegray202
                                                  .copyWith())))
                                ])),
                            Container(
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                  Align(
                                      alignment: Alignment.center,
                                      child: Padding(
                                          padding:
                                              getPadding(left: 4, right: 5),
                                          child: CommonImageView(
                                              svgPath: ImageConstant.imgUser1,
                                              height: getSize(25.00),
                                              width: getSize(25.00)))),
                                  Padding(
                                      padding: getPadding(top: 5),
                                      child: Text("lbl_profile".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle
                                              .txtRalewayRomanRegular12Bluegray202
                                              .copyWith()))
                                ]))
                          ])))
            ])));
  }

  onTapAutoLayoutVer() {
    Get.toNamed(AppRoutes.frameElevenScreen);
  }
}
