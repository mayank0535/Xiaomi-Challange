import '/core/app_export.dart';
import 'package:umango_s_application5/presentation/frame_eleven_screen/models/frame_eleven_model.dart';

class FrameElevenController extends GetxController {
  Rx<FrameElevenModel> frameElevenModelObj = FrameElevenModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
