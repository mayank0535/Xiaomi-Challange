import 'controller/frame_eleven_controller.dart';
import 'package:flutter/material.dart';
import 'package:umango_s_application5/core/app_export.dart';
import 'package:umango_s_application5/widgets/custom_button.dart';

class FrameElevenScreen extends GetWidget<FrameElevenController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                      Container(
                          width: size.width,
                          margin: getMargin(left: 24, top: 47, right: 24),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      GestureDetector(
                                          onTap: () {
                                            onTapImgArrowleft();
                                          },
                                          child: Padding(
                                              padding:
                                                  getPadding(top: 4, bottom: 3),
                                              child: CommonImageView(
                                                  svgPath: ImageConstant
                                                      .imgArrowleft,
                                                  height:
                                                      getVerticalSize(15.00),
                                                  width: getHorizontalSize(
                                                      19.00)))),
                                      Padding(
                                          padding: getPadding(left: 16),
                                          child: Text("lbl_invoice".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRobotoRomanBold24
                                                  .copyWith()))
                                    ]),
                                Padding(
                                    padding: getPadding(top: 1, bottom: 1),
                                    child: CommonImageView(
                                        svgPath: ImageConstant.imgClock,
                                        height: getSize(21.00),
                                        width: getSize(21.00)))
                              ])),
                      Container(
                          width: double.infinity,
                          margin: getMargin(left: 24, top: 36, right: 24),
                          decoration: AppDecoration.outlineBlack9000c1.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder24),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(
                                        left: 28, top: 28, right: 28),
                                    child: ClipRRect(
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(40.00)),
                                        child: CommonImageView(
                                            imagePath: ImageConstant.imgEllipse,
                                            height: getSize(80.00),
                                            width: getSize(80.00)))),
                                Container(
                                    height: getVerticalSize(1.00),
                                    width: getHorizontalSize(271.00),
                                    margin:
                                        getMargin(left: 28, top: 24, right: 28),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.gray200)),
                                Padding(
                                    padding: getPadding(
                                        left: 28, top: 26, right: 28),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                              padding: getPadding(top: 1),
                                              child: Text("lbl_amount_usd".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanMedium16
                                                      .copyWith(
                                                          letterSpacing:
                                                              0.20))),
                                          Padding(
                                              padding: getPadding(bottom: 1),
                                              child: Text("lbl_125".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanSemiBold18
                                                      .copyWith(
                                                          letterSpacing: 0.20)))
                                        ])),
                                Padding(
                                    padding: getPadding(
                                        left: 28, top: 28, right: 28),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                              padding:
                                                  getPadding(top: 1, bottom: 1),
                                              child: Text("lbl_name2".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanMedium16
                                                      .copyWith(
                                                          letterSpacing:
                                                              0.20))),
                                          Text("lbl_abdul_karim".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtRobotoRomanSemiBold18
                                                  .copyWith(
                                                      letterSpacing: 0.20))
                                        ])),
                                Padding(
                                    padding: getPadding(
                                        left: 28, top: 31, right: 28),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                              padding: getPadding(top: 2),
                                              child: Text("lbl_paid_by".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanMedium16
                                                      .copyWith(
                                                          letterSpacing:
                                                              0.20))),
                                          Padding(
                                              padding: getPadding(bottom: 2),
                                              child: Text("lbl_upi_id".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanSemiBold18
                                                      .copyWith(
                                                          letterSpacing: 0.20)))
                                        ])),
                                Padding(
                                    padding: getPadding(
                                        left: 28, top: 29, right: 28),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                              padding: getPadding(bottom: 2),
                                              child: Text("lbl_no_of_items".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanMedium16
                                                      .copyWith(
                                                          letterSpacing:
                                                              0.20))),
                                          Padding(
                                              padding: getPadding(top: 1),
                                              child: Text("lbl_4".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanSemiBold18
                                                      .copyWith(
                                                          letterSpacing: 0.20)))
                                        ])),
                                Padding(
                                    padding: getPadding(
                                        left: 28, top: 33, right: 28),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                              padding: getPadding(
                                                  top: 10, bottom: 12),
                                              child: Text("lbl_order_date".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanMedium16
                                                      .copyWith(
                                                          letterSpacing:
                                                              0.20))),
                                          Container(
                                              width: getHorizontalSize(116.00),
                                              child: Text("msg_dec_24_2024".tr,
                                                  maxLines: null,
                                                  textAlign: TextAlign.right,
                                                  style: AppStyle
                                                      .txtRobotoRomanSemiBold18
                                                      .copyWith(
                                                          letterSpacing: 0.20)))
                                        ])),
                                Padding(
                                    padding: getPadding(
                                        left: 28, top: 33, right: 28),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                              padding: getPadding(bottom: 2),
                                              child: Text("lbl_order_id2".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanMedium16
                                                      .copyWith(
                                                          letterSpacing:
                                                              0.20))),
                                          Padding(
                                              padding: getPadding(top: 1),
                                              child: Text("lbl_362736277289".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanSemiBold18
                                                      .copyWith(
                                                          letterSpacing: 0.20)))
                                        ])),
                                Padding(
                                    padding: getPadding(
                                        left: 28, top: 31, right: 28),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                              padding: getPadding(bottom: 5),
                                              child: Text("lbl_notes".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanMedium16
                                                      .copyWith(
                                                          letterSpacing:
                                                              0.20))),
                                          Padding(
                                              padding:
                                                  getPadding(left: 83, top: 1),
                                              child: Text(
                                                  "msg_deliver_in_even".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanSemiBold18
                                                      .copyWith(
                                                          letterSpacing: 0.20)))
                                        ])),
                                Padding(
                                    padding: getPadding(
                                        left: 28,
                                        top: 24,
                                        right: 28,
                                        bottom: 28),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                              padding:
                                                  getPadding(top: 3, bottom: 4),
                                              child: Text("lbl_status".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRomanMedium16
                                                      .copyWith(
                                                          letterSpacing:
                                                              0.20))),
                                          CustomButton(
                                              width: 66,
                                              text: "lbl_sucessful".tr,
                                              variant: ButtonVariant
                                                  .FillLightgreenA700,
                                              padding:
                                                  ButtonPadding.PaddingAll6,
                                              fontStyle: ButtonFontStyle
                                                  .RobotoRomanSemiBold10)
                                        ]))
                              ])),
                      CustomButton(
                          width: 327,
                          text: "lbl_print_invoice".tr,
                          margin: getMargin(
                              left: 24, top: 34, right: 24, bottom: 20),
                          variant: ButtonVariant.OutlineBlueA7003f,
                          shape: ButtonShape.RoundedBorder27,
                          fontStyle: ButtonFontStyle.RobotoRomanSemiBold16)
                    ]))))));
  }

  onTapImgArrowleft() {
    Get.back();
  }
}
