import '/core/app_export.dart';
import 'package:umango_s_application5/presentation/signup_one_screen/models/signup_one_model.dart';
import 'package:flutter/material.dart';

class SignupOneController extends GetxController {
  TextEditingController frameThirteenController = TextEditingController();

  TextEditingController frameFourteenController = TextEditingController();

  TextEditingController frameFifteenController = TextEditingController();

  Rx<SignupOneModel> signupOneModelObj = SignupOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    frameThirteenController.dispose();
    frameFourteenController.dispose();
    frameFifteenController.dispose();
  }
}
