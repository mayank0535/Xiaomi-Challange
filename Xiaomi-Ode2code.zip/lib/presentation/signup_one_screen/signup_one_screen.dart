import 'controller/signup_one_controller.dart';
import 'package:flutter/material.dart';
import 'package:umango_s_application5/core/app_export.dart';
import 'package:umango_s_application5/core/utils/validation_functions.dart';
import 'package:umango_s_application5/widgets/custom_button.dart';
import 'package:umango_s_application5/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class SignupOneScreen extends GetWidget<SignupOneController> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Form(
                        key: _formKey,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        child: Container(
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                              Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                      width: size.width,
                                      margin: getMargin(
                                          left: 32, top: 48, right: 30),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            CommonImageView(
                                                imagePath: ImageConstant
                                                    .imgVector50X75,
                                                height: getVerticalSize(50.00),
                                                width:
                                                    getHorizontalSize(75.00)),
                                            Padding(
                                                padding: getPadding(
                                                    top: 4, bottom: 21),
                                                child: Text("lbl_sign_up".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtMontserratRomanBold24
                                                        .copyWith()))
                                          ]))),
                              Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                      height: getVerticalSize(252.00),
                                      width: getHorizontalSize(311.00),
                                      margin: getMargin(left: 32, right: 31),
                                      child: Stack(
                                          alignment: Alignment.bottomRight,
                                          children: [
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 62,
                                                        top: 39,
                                                        right: 62,
                                                        bottom: 39),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorGray100,
                                                        height: getVerticalSize(
                                                            118.00),
                                                        width:
                                                            getHorizontalSize(
                                                                49.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 56,
                                                        top: 39,
                                                        right: 56,
                                                        bottom: 39),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgMenu,
                                                        height: getVerticalSize(
                                                            64.00),
                                                        width:
                                                            getHorizontalSize(
                                                                68.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 62,
                                                        top: 61,
                                                        right: 62,
                                                        bottom: 61),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorGray100,
                                                        height: getVerticalSize(
                                                            118.00),
                                                        width:
                                                            getHorizontalSize(
                                                                49.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 9,
                                                        top: 89,
                                                        right: 10,
                                                        bottom: 89),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgNotification24X17,
                                                        height: getVerticalSize(
                                                            24.00),
                                                        width:
                                                            getHorizontalSize(
                                                                17.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                    margin: getMargin(
                                                        left: 15,
                                                        top: 98,
                                                        right: 15,
                                                        bottom: 98),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          CommonImageView(
                                                              svgPath: ImageConstant
                                                                  .imgVectorWhiteA7001X9,
                                                              height:
                                                                  getVerticalSize(
                                                                      1.00),
                                                              width:
                                                                  getHorizontalSize(
                                                                      6.00)),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 1),
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorWhiteA7001X9,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          6.00))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 1),
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorWhiteA7001X9,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          6.00)))
                                                        ]))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 46,
                                                        top: 80,
                                                        right: 46,
                                                        bottom: 80),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgNotification24X17,
                                                        height: getVerticalSize(
                                                            24.00),
                                                        width:
                                                            getHorizontalSize(
                                                                17.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 52,
                                                        top: 93,
                                                        right: 52,
                                                        bottom: 93),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector1X5,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                6.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 52,
                                                        top: 90,
                                                        right: 52,
                                                        bottom: 90),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector1X5,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                6.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 52,
                                                        top: 86,
                                                        right: 52,
                                                        bottom: 86),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector1X5,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                6.00)))),
                                            Container(
                                                height: getVerticalSize(1.00),
                                                width:
                                                    getHorizontalSize(311.00),
                                                margin: getMargin(top: 10),
                                                decoration: BoxDecoration(
                                                    color: ColorConstant
                                                        .bluegray100)),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 63,
                                                        top: 10,
                                                        right: 63,
                                                        bottom: 3),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgReply,
                                                        height: getVerticalSize(
                                                            42.00),
                                                        width:
                                                            getHorizontalSize(
                                                                37.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 63,
                                                        top: 10,
                                                        right: 63,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgReply,
                                                        height: getVerticalSize(
                                                            42.00),
                                                        width:
                                                            getHorizontalSize(
                                                                37.00)))),
                                            Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                    height: getSize(15.00),
                                                    width: getSize(15.00),
                                                    margin: getMargin(
                                                        left: 144,
                                                        top: 80,
                                                        right: 144,
                                                        bottom: 80),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .orangeA700,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    7.79))))),
                                            Align(
                                                alignment: Alignment.topCenter,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 148,
                                                        top: 84,
                                                        right: 148,
                                                        bottom: 84),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgCheckmark,
                                                        height: getVerticalSize(
                                                            6.00),
                                                        width:
                                                            getHorizontalSize(
                                                                7.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 105,
                                                        top: 84,
                                                        right: 105,
                                                        bottom: 84),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgCart,
                                                        height: getVerticalSize(
                                                            38.00),
                                                        width:
                                                            getHorizontalSize(
                                                                49.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 95,
                                                        top: 64,
                                                        right: 95,
                                                        bottom: 64),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgOffer43X28,
                                                        height: getVerticalSize(
                                                            43.00),
                                                        width:
                                                            getHorizontalSize(
                                                                28.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 96,
                                                        top: 10,
                                                        right: 96,
                                                        bottom: 6),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgTrash,
                                                        height: getVerticalSize(
                                                            21.00),
                                                        width:
                                                            getHorizontalSize(
                                                                8.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 95,
                                                        top: 10,
                                                        right: 95,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector9X17,
                                                        height: getVerticalSize(
                                                            9.00),
                                                        width:
                                                            getHorizontalSize(
                                                                17.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 122,
                                                        top: 10,
                                                        right: 122,
                                                        bottom: 6),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgTrash,
                                                        height: getVerticalSize(
                                                            21.00),
                                                        width:
                                                            getHorizontalSize(
                                                                8.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 121,
                                                        top: 10,
                                                        right: 121,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector9X17,
                                                        height: getVerticalSize(
                                                            9.00),
                                                        width:
                                                            getHorizontalSize(
                                                                17.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 82,
                                                        top: 12,
                                                        right: 82,
                                                        bottom: 12),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorBluegray900,
                                                        height: getVerticalSize(
                                                            110.00),
                                                        width:
                                                            getHorizontalSize(
                                                                51.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                    height: getSize(22.00),
                                                    width: getSize(22.00),
                                                    margin: getMargin(
                                                        left: 92,
                                                        top: 30,
                                                        right: 92,
                                                        bottom: 30),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .gray600,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    11.28))))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 80,
                                                        top: 55,
                                                        right: 80,
                                                        bottom: 55),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgNotification80X48,
                                                        height: getVerticalSize(
                                                            80.00),
                                                        width:
                                                            getHorizontalSize(
                                                                48.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 90,
                                                        top: 26,
                                                        right: 90,
                                                        bottom: 26),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgUser,
                                                        height: getVerticalSize(
                                                            18.00),
                                                        width:
                                                            getHorizontalSize(
                                                                24.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 100,
                                                        top: 94,
                                                        right: 100,
                                                        bottom: 94),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgCheckmark47X36,
                                                        height: getVerticalSize(
                                                            47.00),
                                                        width:
                                                            getHorizontalSize(
                                                                36.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 90,
                                                        top: 75,
                                                        right: 90,
                                                        bottom: 75),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVolume24X21,
                                                        height: getVerticalSize(
                                                            24.00),
                                                        width:
                                                            getHorizontalSize(
                                                                21.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 122,
                                                        top: 10,
                                                        right: 122,
                                                        bottom: 6),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgSignal24X9,
                                                        height: getVerticalSize(
                                                            24.00),
                                                        width:
                                                            getHorizontalSize(
                                                                9.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 121,
                                                        top: 10,
                                                        right: 121,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector9X17,
                                                        height: getVerticalSize(
                                                            10.00),
                                                        width:
                                                            getHorizontalSize(
                                                                20.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 94,
                                                        top: 10,
                                                        right: 94,
                                                        bottom: 6),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgSignal24X9,
                                                        height: getVerticalSize(
                                                            24.00),
                                                        width:
                                                            getHorizontalSize(
                                                                9.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 93,
                                                        top: 10,
                                                        right: 93,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector9X17,
                                                        height: getVerticalSize(
                                                            10.00),
                                                        width:
                                                            getHorizontalSize(
                                                                20.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 85,
                                                        top: 15,
                                                        right: 85,
                                                        bottom: 15),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgLocation97X51,
                                                        height: getVerticalSize(
                                                            97.00),
                                                        width:
                                                            getHorizontalSize(
                                                                51.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 78,
                                                        top: 59,
                                                        right: 78,
                                                        bottom: 59),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgLocation83X52,
                                                        height: getVerticalSize(
                                                            83.00),
                                                        width:
                                                            getHorizontalSize(
                                                                52.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Container(
                                                    height: getSize(25.00),
                                                    width: getSize(25.00),
                                                    margin: getMargin(
                                                        left: 88,
                                                        top: 31,
                                                        right: 88,
                                                        bottom: 31),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .deepOrange100,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    12.74))))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 87,
                                                        top: 27,
                                                        right: 87,
                                                        bottom: 27),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgFire,
                                                        height: getVerticalSize(
                                                            29.00),
                                                        width:
                                                            getHorizontalSize(
                                                                31.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 112,
                                                        top: 89,
                                                        right: 112,
                                                        bottom: 89),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgMegaphone,
                                                        height: getVerticalSize(
                                                            30.00),
                                                        width:
                                                            getHorizontalSize(
                                                                51.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 104,
                                                        top: 72,
                                                        right: 104,
                                                        bottom: 72),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgLocation26X20,
                                                        height: getVerticalSize(
                                                            26.00),
                                                        width:
                                                            getHorizontalSize(
                                                                20.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 80,
                                                        top: 87,
                                                        right: 80,
                                                        bottom: 87),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorGray300,
                                                        height: getVerticalSize(
                                                            53.00),
                                                        width:
                                                            getHorizontalSize(
                                                                49.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 84,
                                                        top: 91,
                                                        right: 84,
                                                        bottom: 91),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgOffer43X41,
                                                        height: getVerticalSize(
                                                            43.00),
                                                        width:
                                                            getHorizontalSize(
                                                                41.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 96,
                                                        top: 109,
                                                        right: 96,
                                                        bottom: 109),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorOrangeA700,
                                                        height: getVerticalSize(
                                                            9.00),
                                                        width:
                                                            getHorizontalSize(
                                                                16.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 94,
                                                        top: 113,
                                                        right: 94,
                                                        bottom: 113),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorOrangeA700,
                                                        height: getVerticalSize(
                                                            3.00),
                                                        width:
                                                            getHorizontalSize(
                                                                5.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 92,
                                                        top: 116,
                                                        right: 92,
                                                        bottom: 116),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorOrangeA700,
                                                        height: getVerticalSize(
                                                            6.00),
                                                        width:
                                                            getHorizontalSize(
                                                                11.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 102,
                                                        top: 98,
                                                        right: 102,
                                                        bottom: 98),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorOrangeA700,
                                                        height: getVerticalSize(
                                                            9.00),
                                                        width:
                                                            getHorizontalSize(
                                                                16.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 100,
                                                        top: 101,
                                                        right: 100,
                                                        bottom: 101),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorOrangeA700,
                                                        height: getVerticalSize(
                                                            3.00),
                                                        width:
                                                            getHorizontalSize(
                                                                5.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 98,
                                                        top: 104,
                                                        right: 98,
                                                        bottom: 104),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorOrangeA700,
                                                        height: getVerticalSize(
                                                            6.00),
                                                        width:
                                                            getHorizontalSize(
                                                                11.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 81,
                                                        top: 87,
                                                        right: 81,
                                                        bottom: 87),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgCart,
                                                        height: getVerticalSize(
                                                            45.00),
                                                        width:
                                                            getHorizontalSize(
                                                                39.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 77,
                                                        top: 64,
                                                        right: 77,
                                                        bottom: 64),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgOffer43X28,
                                                        height: getVerticalSize(
                                                            44.00),
                                                        width:
                                                            getHorizontalSize(
                                                                20.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 134,
                                                        top: 93,
                                                        right: 134,
                                                        bottom: 93),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgNotification28X26,
                                                        height: getVerticalSize(
                                                            28.00),
                                                        width:
                                                            getHorizontalSize(
                                                                26.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 140,
                                                        top: 102,
                                                        right: 140,
                                                        bottom: 102),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorWhiteA7007X12,
                                                        height: getVerticalSize(
                                                            7.00),
                                                        width:
                                                            getHorizontalSize(
                                                                12.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 138,
                                                        top: 105,
                                                        right: 138,
                                                        bottom: 105),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorWhiteA7001X9,
                                                        height: getVerticalSize(
                                                            7.00),
                                                        width:
                                                            getHorizontalSize(
                                                                12.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 33,
                                                        right: 33,
                                                        bottom: 10),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorGray10083X123,
                                                        height: getVerticalSize(
                                                            83.00),
                                                        width:
                                                            getHorizontalSize(
                                                                123.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 22,
                                                        top: 59,
                                                        right: 22,
                                                        bottom: 59),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorGray100112X27,
                                                        height: getVerticalSize(
                                                            112.00),
                                                        width:
                                                            getHorizontalSize(
                                                                27.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 21,
                                                        top: 57,
                                                        right: 21,
                                                        bottom: 57),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorGray100112X27,
                                                        height: getVerticalSize(
                                                            112.00),
                                                        width:
                                                            getHorizontalSize(
                                                                27.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 12,
                                                        top: 82,
                                                        right: 12,
                                                        bottom: 82),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector10X10,
                                                        height: getSize(10.00),
                                                        width:
                                                            getSize(10.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 50,
                                                        top: 98,
                                                        right: 50,
                                                        bottom: 98),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector10X10,
                                                        height: getSize(10.00),
                                                        width: getSize(10.00))))
                                          ]))),
                              Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                      padding: getPadding(
                                          left: 32, top: 48, right: 31),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            CommonImageView(
                                                svgPath:
                                                    ImageConstant.imgUser25X25,
                                                height: getSize(25.00),
                                                width: getSize(25.00)),
                                            CustomTextFormField(
                                                width: 266,
                                                focusNode: FocusNode(),
                                                controller: controller
                                                    .frameThirteenController,
                                                hintText: "lbl_full_name".tr,
                                                margin:
                                                    getMargin(left: 20, top: 3),
                                                validator: (value) {
                                                  if (!isText(value)) {
                                                    return "Please enter valid text";
                                                  }
                                                  return null;
                                                })
                                          ]))),
                              Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                      padding: getPadding(
                                          left: 32, top: 32, right: 30),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            CommonImageView(
                                                svgPath: ImageConstant.imgCall,
                                                height: getSize(26.00),
                                                width: getSize(26.00)),
                                            CustomTextFormField(
                                                width: 266,
                                                focusNode: FocusNode(),
                                                controller: controller
                                                    .frameFourteenController,
                                                hintText: "lbl_mobile".tr,
                                                margin:
                                                    getMargin(left: 20, top: 3),
                                                validator: (value) {
                                                  if (!isValidPhone(value)) {
                                                    return "Please enter valid phone number";
                                                  }
                                                  return null;
                                                })
                                          ]))),
                              Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                      padding: getPadding(
                                          left: 32, top: 32, right: 30),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Padding(
                                                padding: getPadding(
                                                    top: 1, bottom: 1),
                                                child: CommonImageView(
                                                    svgPath: ImageConstant
                                                        .imgLocation,
                                                    height:
                                                        getVerticalSize(25.00),
                                                    width: getHorizontalSize(
                                                        26.00))),
                                            CustomTextFormField(
                                                width: 266,
                                                focusNode: FocusNode(),
                                                controller: controller
                                                    .frameFifteenController,
                                                hintText: "lbl_email_id".tr,
                                                margin:
                                                    getMargin(left: 20, top: 3),
                                                textInputAction:
                                                    TextInputAction.done,
                                                validator: (value) {
                                                  if (value == null ||
                                                      (!isValidEmail(value,
                                                          isRequired: true))) {
                                                    return "Please enter valid email";
                                                  }
                                                  return null;
                                                })
                                          ]))),
                              Container(
                                  width: getHorizontalSize(252.00),
                                  margin:
                                      getMargin(left: 32, top: 31, right: 32),
                                  child: RichText(
                                      text: TextSpan(children: [
                                        TextSpan(
                                            text: "msg_by_signing_up2".tr,
                                            style: TextStyle(
                                                color:
                                                    ColorConstant.bluegray202,
                                                fontSize: getFontSize(12),
                                                fontFamily: 'Montserrat',
                                                fontWeight: FontWeight.w300)),
                                        TextSpan(
                                            text: "msg_terms_conditi".tr,
                                            style: TextStyle(
                                                color: ColorConstant.blue900,
                                                fontSize: getFontSize(12),
                                                fontFamily: 'Montserrat',
                                                fontWeight: FontWeight.w300)),
                                        TextSpan(
                                            text: "lbl_and".tr,
                                            style: TextStyle(
                                                color:
                                                    ColorConstant.bluegray202,
                                                fontSize: getFontSize(12),
                                                fontFamily: 'Montserrat',
                                                fontWeight: FontWeight.w300)),
                                        TextSpan(
                                            text: "lbl_privacy_policy".tr,
                                            style: TextStyle(
                                                color: ColorConstant.blue900,
                                                fontSize: getFontSize(12),
                                                fontFamily: 'Montserrat',
                                                fontWeight: FontWeight.w300))
                                      ]),
                                      textAlign: TextAlign.left)),
                              CustomButton(
                                  width: 311,
                                  text: "lbl_continue".tr,
                                  margin:
                                      getMargin(left: 32, top: 12, right: 32),
                                  onTap: onTapBtnContinue,
                                  alignment: Alignment.center),
                              GestureDetector(
                                  onTap: () {
                                    onTapTxtJoinedusbefor();
                                  },
                                  child: Container(
                                      margin: getMargin(
                                          left: 32,
                                          top: 31,
                                          right: 32,
                                          bottom: 20),
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text: "msg_joined_us_befor2".tr,
                                                style: TextStyle(
                                                    color: ColorConstant
                                                        .bluegray202,
                                                    fontSize: getFontSize(20),
                                                    fontFamily: 'Montserrat',
                                                    fontWeight:
                                                        FontWeight.w500)),
                                            TextSpan(
                                                text: "lbl_sign_in".tr,
                                                style: TextStyle(
                                                    color:
                                                        ColorConstant.blue900,
                                                    fontSize: getFontSize(20),
                                                    fontFamily: 'Montserrat',
                                                    fontWeight:
                                                        FontWeight.w500))
                                          ]),
                                          textAlign: TextAlign.left)))
                            ])))))));
  }

  onTapBtnContinue() {
    Get.toNamed(AppRoutes.signupScreen);
  }

  onTapTxtJoinedusbefor() {
    Get.toNamed(AppRoutes.signinScreen);
  }
}
