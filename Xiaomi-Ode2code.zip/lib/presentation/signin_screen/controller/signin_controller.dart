import '/core/app_export.dart';
import 'package:umango_s_application5/presentation/signin_screen/models/signin_model.dart';
import 'package:flutter/material.dart';

class SigninController extends GetxController {
  TextEditingController frameFifteenController = TextEditingController();

  TextEditingController frameFourteenController = TextEditingController();

  Rx<SigninModel> signinModelObj = SigninModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    frameFifteenController.dispose();
    frameFourteenController.dispose();
  }
}
