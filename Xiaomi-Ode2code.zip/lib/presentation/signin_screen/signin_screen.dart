import 'controller/signin_controller.dart';
import 'package:flutter/material.dart';
import 'package:umango_s_application5/core/app_export.dart';
import 'package:umango_s_application5/core/utils/validation_functions.dart';
import 'package:umango_s_application5/widgets/custom_button.dart';
import 'package:umango_s_application5/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class SigninScreen extends GetWidget<SigninController> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Form(
                        key: _formKey,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        child: Container(
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                              Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                      width: size.width,
                                      margin: getMargin(
                                          left: 31, top: 48, right: 31),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            CommonImageView(
                                                imagePath: ImageConstant
                                                    .imgVector50X75,
                                                height: getVerticalSize(50.00),
                                                width:
                                                    getHorizontalSize(75.00)),
                                            Padding(
                                                padding: getPadding(
                                                    top: 4, bottom: 21),
                                                child: Text("lbl_sign_in".tr,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtMontserratRomanBold24
                                                        .copyWith()))
                                          ]))),
                              Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                      height: getVerticalSize(202.00),
                                      width: getHorizontalSize(310.00),
                                      margin: getMargin(left: 31, right: 31),
                                      child: Stack(
                                          alignment: Alignment.bottomRight,
                                          children: [
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 10,
                                                        top: 78,
                                                        right: 5,
                                                        bottom: 78),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector,
                                                        height: getVerticalSize(
                                                            18.00),
                                                        width:
                                                            getHorizontalSize(
                                                                14.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Container(
                                                    width:
                                                        getHorizontalSize(9.00),
                                                    margin: getMargin(
                                                        left: 10,
                                                        top: 85,
                                                        right: 6,
                                                        bottom: 85),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          CommonImageView(
                                                              svgPath: ImageConstant
                                                                  .imgVectorWhiteA7001X9,
                                                              height:
                                                                  getVerticalSize(
                                                                      1.00),
                                                              width:
                                                                  getHorizontalSize(
                                                                      9.00)),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 1),
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorWhiteA7001X9,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          9.00)))
                                                        ]))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                    height: getSize(116.00),
                                                    width: getSize(116.00),
                                                    margin: getMargin(
                                                        left: 26,
                                                        top: 6,
                                                        right: 26,
                                                        bottom: 10),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .gray100,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    58.11))))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                child: Container(
                                                    height: getSize(22.00),
                                                    width: getSize(22.00),
                                                    margin: getMargin(
                                                        left: 141,
                                                        top: 81,
                                                        right: 141,
                                                        bottom: 81),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .gray100,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    11.01))))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Container(
                                                    height: getSize(8.00),
                                                    width: getSize(8.00),
                                                    margin: getMargin(
                                                        left: 99,
                                                        top: 56,
                                                        right: 99,
                                                        bottom: 56),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .gray100,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    4.47))))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 68,
                                                        top: 10,
                                                        right: 68,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector75X28,
                                                        height: getVerticalSize(
                                                            75.00),
                                                        width:
                                                            getHorizontalSize(
                                                                28.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 76,
                                                        top: 10,
                                                        right: 76,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgEye,
                                                        height: getVerticalSize(
                                                            75.00),
                                                        width:
                                                            getHorizontalSize(
                                                                17.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 73,
                                                        top: 48,
                                                        right: 73,
                                                        bottom: 48),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector9X6,
                                                        height: getVerticalSize(
                                                            9.00),
                                                        width:
                                                            getHorizontalSize(
                                                                6.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 82,
                                                        top: 30,
                                                        right: 82,
                                                        bottom: 30),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector10X8,
                                                        height: getVerticalSize(
                                                            10.00),
                                                        width:
                                                            getHorizontalSize(
                                                                8.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 85,
                                                        top: 64,
                                                        right: 85,
                                                        bottom: 64),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorWhiteA7001X5,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                5.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 76,
                                                        top: 10,
                                                        right: 76,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgEye52X58,
                                                        height: getVerticalSize(
                                                            52.00),
                                                        width:
                                                            getHorizontalSize(
                                                                58.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 76,
                                                        top: 10,
                                                        right: 76,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgEye50X58,
                                                        height: getVerticalSize(
                                                            50.00),
                                                        width:
                                                            getHorizontalSize(
                                                                58.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Container(
                                                    width: getHorizontalSize(
                                                        28.00),
                                                    margin: getMargin(
                                                        left: 98,
                                                        top: 20,
                                                        right: 98,
                                                        bottom: 20),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          right:
                                                                              6),
                                                                  child: Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      children: [
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(top: 1, bottom: 7),
                                                                            child: CommonImageView(svgPath: ImageConstant.imgVectorWhiteA7001X5, height: getVerticalSize(3.00), width: getHorizontalSize(4.00))),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 14),
                                                                            child: CommonImageView(svgPath: ImageConstant.imgVectorWhiteA70011X2, height: getVerticalSize(11.00), width: getHorizontalSize(2.00)))
                                                                      ]))),
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerRight,
                                                              child: Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          left:
                                                                              10,
                                                                          top:
                                                                              12),
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgVectorWhiteA7003X12,
                                                                      height: getVerticalSize(
                                                                          3.00),
                                                                      width: getHorizontalSize(
                                                                          12.00))))
                                                        ]))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 14,
                                                        top: 56,
                                                        right: 14,
                                                        bottom: 56),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgLightbulb,
                                                        height: getVerticalSize(
                                                            52.00),
                                                        width:
                                                            getHorizontalSize(
                                                                11.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 58,
                                                        top: 10,
                                                        right: 58,
                                                        bottom: 4),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgSignal,
                                                        height: getVerticalSize(
                                                            17.00),
                                                        width:
                                                            getHorizontalSize(
                                                                6.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 57,
                                                        top: 10,
                                                        right: 57,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector7X14,
                                                        height: getVerticalSize(
                                                            7.00),
                                                        width:
                                                            getHorizontalSize(
                                                                14.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 18,
                                                        top: 10,
                                                        right: 18,
                                                        bottom: 4),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgSignal,
                                                        height: getVerticalSize(
                                                            17.00),
                                                        width:
                                                            getHorizontalSize(
                                                                6.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 17,
                                                        top: 10,
                                                        right: 17,
                                                        bottom: 1),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector7X14,
                                                        height: getVerticalSize(
                                                            7.00),
                                                        width:
                                                            getHorizontalSize(
                                                                14.00)))),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 17,
                                                        top: 12,
                                                        right: 17,
                                                        bottom: 12),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgHome,
                                                        height: getVerticalSize(
                                                            87.00),
                                                        width:
                                                            getHorizontalSize(
                                                                52.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Container(
                                                    height: getSize(18.00),
                                                    width: getSize(18.00),
                                                    margin: getMargin(
                                                        left: 34,
                                                        top: 10,
                                                        right: 34,
                                                        bottom: 10),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .deepOrange100,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    9.44))))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 15,
                                                        top: 39,
                                                        right: 15,
                                                        bottom: 39),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVolume,
                                                        height: getVerticalSize(
                                                            26.00),
                                                        width:
                                                            getHorizontalSize(
                                                                14.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 55,
                                                        top: 57,
                                                        right: 55,
                                                        bottom: 57),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgSignal51X27,
                                                        height: getVerticalSize(
                                                            51.00),
                                                        width:
                                                            getHorizontalSize(
                                                                27.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 50,
                                                        top: 40,
                                                        right: 50,
                                                        bottom: 40),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgOffer,
                                                        height: getVerticalSize(
                                                            23.00),
                                                        width:
                                                            getHorizontalSize(
                                                                15.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 21,
                                                        top: 32,
                                                        right: 21,
                                                        bottom: 32),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector76X42,
                                                        height: getVerticalSize(
                                                            76.00),
                                                        width:
                                                            getHorizontalSize(
                                                                42.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 32,
                                                        top: 7,
                                                        right: 32,
                                                        bottom: 10),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgCar,
                                                        height: getVerticalSize(
                                                            20.00),
                                                        width:
                                                            getHorizontalSize(
                                                                24.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 75,
                                                        top: 62,
                                                        right: 75,
                                                        bottom: 62),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorBluegray800,
                                                        height: getVerticalSize(
                                                            63.00),
                                                        width:
                                                            getHorizontalSize(
                                                                111.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 119,
                                                        top: 51,
                                                        right: 119,
                                                        bottom: 51),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVolume19X14,
                                                        height: getVerticalSize(
                                                            19.00),
                                                        width:
                                                            getHorizontalSize(
                                                                14.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 70,
                                                        top: 71,
                                                        right: 70,
                                                        bottom: 71),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgNotification,
                                                        height: getVerticalSize(
                                                            20.00),
                                                        width:
                                                            getHorizontalSize(
                                                                14.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 122,
                                                        top: 61,
                                                        right: 122,
                                                        bottom: 61),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector1X5,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                5.00)))),
                                            Align(
                                                alignment: Alignment.bottomLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 122,
                                                        top: 58,
                                                        right: 122,
                                                        bottom: 58),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector1X5,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                9.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 74,
                                                        top: 79,
                                                        right: 74,
                                                        bottom: 79),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorWhiteA7001X9,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                5.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 74,
                                                        top: 82,
                                                        right: 74,
                                                        bottom: 82),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorWhiteA7001X9,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                5.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 74,
                                                        top: 85,
                                                        right: 74,
                                                        bottom: 85),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorWhiteA7001X9,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                5.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 77,
                                                        top: 76,
                                                        right: 77,
                                                        bottom: 76),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgBookmark,
                                                        height: getVerticalSize(
                                                            28.00),
                                                        width:
                                                            getHorizontalSize(
                                                                42.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 80,
                                                        top: 79,
                                                        right: 80,
                                                        bottom: 79),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgComputer,
                                                        height: getVerticalSize(
                                                            23.00),
                                                        width:
                                                            getHorizontalSize(
                                                                36.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Container(
                                                    width: getHorizontalSize(
                                                        25.00),
                                                    margin: getMargin(
                                                        left: 85,
                                                        top: 86,
                                                        right: 85,
                                                        bottom: 86),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Align(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorOrangeA700,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width: getHorizontalSize(
                                                                      25.00))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 1,
                                                                      right:
                                                                          10),
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorOrangeA700,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          5.00))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 1,
                                                                      right:
                                                                          10),
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorOrangeA700,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          11.00)))
                                                        ]))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Container(
                                                    height: getSize(14.00),
                                                    width: getSize(14.00),
                                                    margin: getMargin(
                                                        left: 113,
                                                        top: 68,
                                                        right: 113,
                                                        bottom: 68),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .bluegray800,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    7.39))))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 106,
                                                        top: 4,
                                                        right: 106,
                                                        bottom: 10),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector23X38,
                                                        height: getVerticalSize(
                                                            23.00),
                                                        width:
                                                            getHorizontalSize(
                                                                38.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 100,
                                                        top: 13,
                                                        right: 100,
                                                        bottom: 13),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector,
                                                        height: getVerticalSize(
                                                            19.00),
                                                        width:
                                                            getHorizontalSize(
                                                                15.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 104,
                                                        top: 23,
                                                        right: 104,
                                                        bottom: 23),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector1X9,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                9.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 104,
                                                        top: 20,
                                                        right: 104,
                                                        bottom: 20),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorWhiteA7001X9,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                9.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 122,
                                                        right: 122,
                                                        bottom: 10),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgBookmark,
                                                        height: getVerticalSize(
                                                            28.00),
                                                        width:
                                                            getHorizontalSize(
                                                                42.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 124,
                                                        top: 2,
                                                        right: 124,
                                                        bottom: 10),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgComputer,
                                                        height: getVerticalSize(
                                                            23.00),
                                                        width:
                                                            getHorizontalSize(
                                                                36.00)))),
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Container(
                                                    width: getHorizontalSize(
                                                        25.00),
                                                    margin: getMargin(
                                                        left: 130,
                                                        top: 10,
                                                        right: 130,
                                                        bottom: 10),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Align(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorOrangeA7001X25,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width: getHorizontalSize(
                                                                      25.00))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 1,
                                                                      right:
                                                                          10),
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorOrangeA7001X25,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          5.00))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 1,
                                                                      right:
                                                                          10),
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorOrangeA700,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          11.00)))
                                                        ]))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                    height: getSize(20.00),
                                                    width: getSize(20.00),
                                                    margin: getMargin(
                                                        left: 134,
                                                        top: 18,
                                                        right: 134,
                                                        bottom: 18),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .bluegray800,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    10.19))))),
                                            Container(
                                                height: getVerticalSize(1.00),
                                                width:
                                                    getHorizontalSize(102.00),
                                                margin: getMargin(
                                                    left: 10, top: 10),
                                                decoration: BoxDecoration(
                                                    color: ColorConstant
                                                        .bluegray100)),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 44,
                                                        top: 42,
                                                        right: 44,
                                                        bottom: 42),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector43X62,
                                                        height: getVerticalSize(
                                                            43.00),
                                                        width:
                                                            getHorizontalSize(
                                                                62.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 61,
                                                        top: 34,
                                                        right: 61,
                                                        bottom: 34),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVolume19X14,
                                                        height: getVerticalSize(
                                                            19.00),
                                                        width:
                                                            getHorizontalSize(
                                                                14.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 64,
                                                        top: 41,
                                                        right: 64,
                                                        bottom: 41),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector1X5,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                5.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 64,
                                                        top: 45,
                                                        right: 64,
                                                        bottom: 45),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorWhiteA7001X9,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                9.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        top: 57,
                                                        right: 10,
                                                        bottom: 57),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgBookmark,
                                                        height: getVerticalSize(
                                                            28.00),
                                                        width:
                                                            getHorizontalSize(
                                                                42.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 2,
                                                        top: 59,
                                                        right: 10,
                                                        bottom: 59),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgComputer23X36,
                                                        height: getVerticalSize(
                                                            23.00),
                                                        width:
                                                            getHorizontalSize(
                                                                36.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                    height:
                                                        getVerticalSize(1.00),
                                                    width: getHorizontalSize(
                                                        25.00),
                                                    margin: getMargin(
                                                        left: 8,
                                                        top: 67,
                                                        right: 10,
                                                        bottom: 67),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .orangeA700,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    0.79))))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                    margin: getMargin(
                                                        left: 8,
                                                        top: 70,
                                                        right: 10,
                                                        bottom: 70),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      right: 6),
                                                              child: CommonImageView(
                                                                  svgPath:
                                                                      ImageConstant
                                                                          .imgVectorOrangeA700,
                                                                  height:
                                                                      getVerticalSize(
                                                                          1.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          5.00))),
                                                          Align(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              child: Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              1),
                                                                  child: CommonImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgVectorOrangeA700,
                                                                      height: getVerticalSize(
                                                                          1.00),
                                                                      width: getHorizontalSize(
                                                                          11.00))))
                                                        ]))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                    height: getSize(20.00),
                                                    width: getSize(20.00),
                                                    margin: getMargin(
                                                        left: 35,
                                                        top: 74,
                                                        right: 35,
                                                        bottom: 74),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .bluegray800,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    10.19))))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 99,
                                                        top: 55,
                                                        right: 99,
                                                        bottom: 55),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgNotification19X14,
                                                        height: getVerticalSize(
                                                            19.00),
                                                        width:
                                                            getHorizontalSize(
                                                                14.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 102,
                                                        top: 62,
                                                        right: 102,
                                                        bottom: 62),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVector1X5,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                5.00)))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Padding(
                                                    padding: getPadding(
                                                        left: 102,
                                                        top: 65,
                                                        right: 102,
                                                        bottom: 65),
                                                    child: CommonImageView(
                                                        svgPath: ImageConstant
                                                            .imgVectorWhiteA7001X9,
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                9.00))))
                                          ]))),
                              Padding(
                                  padding:
                                      getPadding(left: 31, top: 15, right: 31),
                                  child: Text("lbl_welcome_back".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle
                                          .txtMontserratRomanSemiBold32
                                          .copyWith())),
                              Padding(
                                  padding:
                                      getPadding(left: 31, top: 19, right: 31),
                                  child: Text("msg_welcome_back_p".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtMontserratRomanLight14
                                          .copyWith())),
                              Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                      padding: getPadding(
                                          left: 31, top: 48, right: 31),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Padding(
                                                padding: getPadding(
                                                    top: 1, bottom: 1),
                                                child: CommonImageView(
                                                    svgPath: ImageConstant
                                                        .imgLocation,
                                                    height:
                                                        getVerticalSize(25.00),
                                                    width: getHorizontalSize(
                                                        26.00))),
                                            CustomTextFormField(
                                                width: 266,
                                                focusNode: FocusNode(),
                                                controller: controller
                                                    .frameFifteenController,
                                                hintText: "lbl_email_id".tr,
                                                margin:
                                                    getMargin(left: 20, top: 3),
                                                validator: (value) {
                                                  if (value == null ||
                                                      (!isValidEmail(value,
                                                          isRequired: true))) {
                                                    return "Please enter valid email";
                                                  }
                                                  return null;
                                                })
                                          ]))),
                              Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                      padding: getPadding(
                                          left: 31, top: 32, right: 31),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            CommonImageView(
                                                svgPath: ImageConstant.imgCall,
                                                height: getSize(26.00),
                                                width: getSize(26.00)),
                                            CustomTextFormField(
                                                width: 266,
                                                focusNode: FocusNode(),
                                                controller: controller
                                                    .frameFourteenController,
                                                hintText: "lbl_mobile".tr,
                                                margin:
                                                    getMargin(left: 20, top: 3),
                                                textInputAction:
                                                    TextInputAction.done,
                                                validator: (value) {
                                                  if (!isValidPhone(value)) {
                                                    return "Please enter valid phone number";
                                                  }
                                                  return null;
                                                })
                                          ]))),
                              Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                      padding: getPadding(
                                          left: 31, top: 32, right: 31),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Padding(
                                                padding: getPadding(
                                                    top: 1, bottom: 1),
                                                child: CommonImageView(
                                                    svgPath: ImageConstant
                                                        .imgGroup58,
                                                    height: getSize(25.00),
                                                    width: getSize(25.00))),
                                            Container(
                                                margin: getMargin(left: 20),
                                                child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                          width:
                                                              getHorizontalSize(
                                                                  266.00),
                                                          child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                Padding(
                                                                    padding: getPadding(
                                                                        top: 3,
                                                                        bottom:
                                                                            1),
                                                                    child: Text(
                                                                        "lbl_password"
                                                                            .tr,
                                                                        overflow:
                                                                            TextOverflow
                                                                                .ellipsis,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .left,
                                                                        style: AppStyle
                                                                            .txtMontserratRomanMedium14
                                                                            .copyWith())),
                                                                CommonImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgDashboard,
                                                                    height:
                                                                        getVerticalSize(
                                                                            17.00),
                                                                    width: getHorizontalSize(
                                                                        20.00))
                                                              ])),
                                                      Container(
                                                          height:
                                                              getVerticalSize(
                                                                  2.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  266.00),
                                                          margin:
                                                              getMargin(top: 8),
                                                          decoration: BoxDecoration(
                                                              color: ColorConstant
                                                                  .bluegray202))
                                                    ]))
                                          ]))),
                              CustomButton(
                                  width: 311,
                                  text: "lbl_sign_in".tr,
                                  margin:
                                      getMargin(left: 31, top: 28, right: 31),
                                  onTap: onTapBtnSignin,
                                  alignment: Alignment.center),
                              GestureDetector(
                                  onTap: () {
                                    onTapTxtNewtomisign();
                                  },
                                  child: Container(
                                      margin: getMargin(
                                          left: 31,
                                          top: 31,
                                          right: 31,
                                          bottom: 20),
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text: "lbl_new_to_mi".tr,
                                                style: TextStyle(
                                                    color: ColorConstant
                                                        .bluegray202,
                                                    fontSize: getFontSize(20),
                                                    fontFamily: 'Montserrat',
                                                    fontWeight:
                                                        FontWeight.w500)),
                                            TextSpan(
                                                text: "lbl_sign_up".tr,
                                                style: TextStyle(
                                                    color:
                                                        ColorConstant.blue900,
                                                    fontSize: getFontSize(20),
                                                    fontFamily: 'Montserrat',
                                                    fontWeight:
                                                        FontWeight.w500))
                                          ]),
                                          textAlign: TextAlign.left)))
                            ])))))));
  }

  onTapBtnSignin() {
    Get.toNamed(AppRoutes.homepageScreen);
  }

  onTapTxtNewtomisign() {
    Get.toNamed(AppRoutes.signupOneScreen);
  }
}
