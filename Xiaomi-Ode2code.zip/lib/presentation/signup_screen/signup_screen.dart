import 'controller/signup_controller.dart';
import 'package:flutter/material.dart';
import 'package:umango_s_application5/core/app_export.dart';
import 'package:umango_s_application5/widgets/custom_button.dart';

class SignupScreen extends GetWidget<SignupController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                      Container(
                          width: size.width,
                          margin: getMargin(left: 32, top: 48, right: 30),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                CommonImageView(
                                    imagePath: ImageConstant.imgVector50X75,
                                    height: getVerticalSize(50.00),
                                    width: getHorizontalSize(75.00)),
                                Padding(
                                    padding: getPadding(top: 4, bottom: 21),
                                    child: Text("lbl_sign_up".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtMontserratRomanBold24
                                            .copyWith()))
                              ])),
                      Padding(
                          padding: getPadding(left: 32, top: 48, right: 31),
                          child: CommonImageView(
                              svgPath: ImageConstant.imgUndrawagreemen,
                              height: getVerticalSize(300.00),
                              width: getHorizontalSize(311.00))),
                      Container(
                          width: getHorizontalSize(300.00),
                          margin: getMargin(left: 32, top: 43, right: 32),
                          child: Text("msg_you_will_get_th".tr,
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtMontserratRomanMedium20Gray900
                                  .copyWith())),
                      CustomButton(
                          width: 311,
                          text: "lbl_back_to_sign_in".tr,
                          margin: getMargin(
                              left: 32, top: 44, right: 31, bottom: 20),
                          onTap: onTapBtnBacktosignin)
                    ]))))));
  }

  onTapBtnBacktosignin() {
    Get.toNamed(AppRoutes.signinScreen);
  }
}
