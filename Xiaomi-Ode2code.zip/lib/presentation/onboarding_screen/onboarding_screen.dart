import 'controller/onboarding_controller.dart';
import 'package:flutter/material.dart';
import 'package:umango_s_application5/core/app_export.dart';

class OnboardingScreen extends GetWidget<OnboardingController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        height: size.height,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment(
                                    0.999999970793721, 0.5000000083527992),
                                end: Alignment(
                                    -2.9206278395754737e-8, 0.4999999999999997),
                                colors: [
                              ColorConstant.orangeA700,
                              ColorConstant.orangeA700
                            ])),
                        child: GestureDetector(
                            onTap: () {
                              onTapOnboarding();
                            },
                            child: Container(
                                height: size.height,
                                width: size.width,
                                child: Stack(children: [
                                  Align(
                                      alignment: Alignment.center,
                                      child: Padding(
                                          padding: getPadding(
                                              left: 40,
                                              top: 40,
                                              right: 40,
                                              bottom: 20),
                                          child: CommonImageView(
                                              svgPath: ImageConstant
                                                  .imgVectorWhiteA700,
                                              height: getVerticalSize(100.00),
                                              width:
                                                  getHorizontalSize(150.00))))
                                ]))))))));
  }

  onTapOnboarding() {
    Get.toNamed(AppRoutes.signinScreen);
  }
}
