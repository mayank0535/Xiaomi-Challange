class ImageConstant {
  static String imgLocation97X51 = 'assets/images/img_location_97X51.svg';

  static String imgEye52X58 = 'assets/images/img_eye_52X58.svg';

  static String imgVectorWhiteA7001X9 =
      'assets/images/img_vector_white_A700_1X9.svg';

  static String imgCar = 'assets/images/img_car.svg';

  static String imgQrcode = 'assets/images/img_qrcode.svg';

  static String imgVector10X8 = 'assets/images/img_vector_10X8.svg';

  static String imgVector1X9 = 'assets/images/img_vector_1X9.svg';

  static String imgUnsplashf4qyr3 = 'assets/images/img_unsplashf4qyr3.png';

  static String imgVectorWhiteA70011X2 =
      'assets/images/img_vector_white_A700_11X2.svg';

  static String imgUnsplashagzyfs = 'assets/images/img_unsplashagzyfs.png';

  static String imgNotification28X26 =
      'assets/images/img_notification_28X26.svg';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgVector7X14 = 'assets/images/img_vector_7X14.svg';

  static String imgVector10X10 = 'assets/images/img_vector_10X10.svg';

  static String imgLocation83X52 = 'assets/images/img_location_83X52.svg';

  static String imgSchema = 'assets/images/img_schema.png';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgVectorOrangeA700 =
      'assets/images/img_vector_orange_A700.svg';

  static String imgVector23X38 = 'assets/images/img_vector_23X38.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgOffer43X41 = 'assets/images/img_offer_43X41.svg';

  static String imgCheckmark47X36 = 'assets/images/img_checkmark_47X36.svg';

  static String imgReply = 'assets/images/img_reply.svg';

  static String imgVectorBluegray900 =
      'assets/images/img_vector_bluegray_900.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgEllipse = 'assets/images/img_ellipse.png';

  static String imgUnsplashgrzokn = 'assets/images/img_unsplashgrzokn.png';

  static String imgVolume19X14 = 'assets/images/img_volume_19X14.svg';

  static String imgArrowleftBluegray101 =
      'assets/images/img_arrowleft_bluegray_101.svg';

  static String imgGroup30 = 'assets/images/img_group30.png';

  static String imgVectorWhiteA7003X12 =
      'assets/images/img_vector_white_A700_3X12.svg';

  static String imgUser25X25 = 'assets/images/img_user_25X25.svg';

  static String imgVector75X28 = 'assets/images/img_vector_75X28.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgOffer43X28 = 'assets/images/img_offer_43X28.svg';

  static String imgMegaphone = 'assets/images/img_megaphone.svg';

  static String imgVectorBluegray800 =
      'assets/images/img_vector_bluegray_800.svg';

  static String imgDashboard = 'assets/images/img_dashboard.svg';

  static String imgVector43X62 = 'assets/images/img_vector_43X62.svg';

  static String imgVector1X5 = 'assets/images/img_vector_1X5.svg';

  static String imgVector76X42 = 'assets/images/img_vector_76X42.svg';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgNotification24X17 =
      'assets/images/img_notification_24X17.svg';

  static String imgEye50X58 = 'assets/images/img_eye_50X58.svg';

  static String imgBookmark = 'assets/images/img_bookmark.svg';

  static String imgFire = 'assets/images/img_fire.svg';

  static String imgVectorGray300 = 'assets/images/img_vector_gray_300.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgLocation26X20 = 'assets/images/img_location_26X20.svg';

  static String imgNotification19X14 =
      'assets/images/img_notification_19X14.svg';

  static String imgNotification80X48 =
      'assets/images/img_notification_80X48.svg';

  static String imgNotification = 'assets/images/img_notification.svg';

  static String imgVectorWhiteA7007X12 =
      'assets/images/img_vector_white_A700_7X12.svg';

  static String imgUser1 = 'assets/images/img_user_1.svg';

  static String imgVolume24X21 = 'assets/images/img_volume_24X21.svg';

  static String imgSignal51X27 = 'assets/images/img_signal_51X27.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgVectorWhiteA700 = 'assets/images/img_vector_white_A700.svg';

  static String imgUndrawagreemen = 'assets/images/img_undrawagreemen.svg';

  static String imgVector9X6 = 'assets/images/img_vector_9X6.svg';

  static String imgUnsplashlxvxpa = 'assets/images/img_unsplashlxvxpa.png';

  static String imgCall = 'assets/images/img_call.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgVector9X17 = 'assets/images/img_vector_9X17.svg';

  static String imgSignal24X9 = 'assets/images/img_signal_24X9.svg';

  static String imgHome19X20 = 'assets/images/img_home_19X20.svg';

  static String imgEllipse1 = 'assets/images/img_ellipse1.png';

  static String imgUnsplashylverp = 'assets/images/img_unsplashylverp.png';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgVectorGray100 = 'assets/images/img_vector_gray_100.svg';

  static String imgCart = 'assets/images/img_cart.svg';

  static String imgUnsplashsg8nx = 'assets/images/img_unsplashsg8nx.png';

  static String imgVectorGray10083X123 =
      'assets/images/img_vector_gray_100_83X123.svg';

  static String imgOffer = 'assets/images/img_offer.svg';

  static String imgCart18X20 = 'assets/images/img_cart_18X20.svg';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgVector50X75 = 'assets/images/img_vector_50X75.png';

  static String imgTrash = 'assets/images/img_trash.svg';

  static String imgVectorGray100112X27 =
      'assets/images/img_vector_gray_100_112X27.svg';

  static String imgComputer = 'assets/images/img_computer.svg';

  static String imgGroup58 = 'assets/images/img_group58.svg';

  static String imgComputer23X36 = 'assets/images/img_computer_23X36.svg';

  static String imgVectorOrangeA7001X25 =
      'assets/images/img_vector_orange_A700_1X25.svg';

  static String imgVectorWhiteA7001X5 =
      'assets/images/img_vector_white_A700_1X5.svg';

  static String imgMinimize = 'assets/images/img_minimize.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
