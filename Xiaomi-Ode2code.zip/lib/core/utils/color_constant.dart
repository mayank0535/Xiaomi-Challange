import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color blueA700 = fromHex('#246bfd');

  static Color lightGreenA700 = fromHex('#19fa14');

  static Color black904 = fromHex('#000000');

  static Color black903 = fromHex('#060405');

  static Color black900 = fromHex('#070918');

  static Color black902 = fromHex('#050402');

  static Color black9000c1 = fromHex('#0c04060f');

  static Color black901 = fromHex('#000000');

  static Color gray500Bf = fromHex('#bf999999');

  static Color deepOrange100 = fromHex('#ffb8b8');

  static Color blueA7003f = fromHex('#3f246bfd');

  static Color gray600 = fromHex('#a0616a');

  static Color gray601 = fromHex('#757575');

  static Color gray700 = fromHex('#616161');

  static Color blue900 = fromHex('#004abb');

  static Color bluegray2007f = fromHex('#7fb7bac8');

  static Color gray901 = fromHex('#212121');

  static Color orangeA700 = fromHex('#ff6801');

  static Color gray900 = fromHex('#00132f');

  static Color bluegray100 = fromHex('#cccccc');

  static Color bluegray10063 = fromHex('#63d1ccdb');

  static Color black9000c = fromHex('#0c000000');

  static Color gray200 = fromHex('#eeeeee');

  static Color gray100 = fromHex('#f2f2f2');

  static Color bluegray800 = fromHex('#3f3d56');

  static Color black90099 = fromHex('#99000000');

  static Color bluegray203 = fromHex('#b7bccf');

  static Color bluegray202 = fromHex('#b7bac8');

  static Color bluegray103 = fromHex('#d1ccdb');

  static Color bluegray400 = fromHex('#888888');

  static Color bluegray200 = fromHex('#b6bbcf');

  static Color gray400Bf = fromHex('#bfb5b5b5');

  static Color black90019 = fromHex('#19000000');

  static Color whiteA700 = fromHex('#ffffff');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
