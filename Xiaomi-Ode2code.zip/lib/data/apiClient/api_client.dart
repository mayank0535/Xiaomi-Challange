import 'package:umango_s_application5/core/app_export.dart';

class ApiClient extends GetConnect {}
